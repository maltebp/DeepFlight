

Windows:
	Just run the executable file

Linux:
	sudo apt update
	sudo apt install mono-complete 
	mono DeepFlight.exe

Mac:
	Not tested (probably just the same as Linux)