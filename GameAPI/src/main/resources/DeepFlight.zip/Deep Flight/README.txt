
==============================================
		DEEP FLIGHT
==============================================

	      Game Developed
	    by Malte B. Pedersen

		  Website:
		maltebp.dk

		  Github:
      github.com/maltebp/DeepFlightGame


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		 DISCLAIMER
		
LOGIN
To play online you need a profile provided by the
course '62597 Backend Development, Operation and 
Distributed Systems' at DTU.

You may also use one of the public profiles:

	username: adminX
	password: adminX

where X is a number between 0 and 100 (i.e.
username 'admin0' and password 'admin0')


SCREEN RESOLUTIONS
Only the following screen resolutions are supported:
	
	1920x1080
        1600x900
        1366x768
	1360x768
        1280x720
        1440x900

Running with any other resolution will cause the game
not to start.


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	   RUNNING THE PROGRAM

WINDOWS:
Just run the executable ('DeepFlight.exe') by
clicking on it

LINUX:
Install 'mono' and run it via terminal:

	1) Go to terminal
	2) Write commands to install 'mono':
		sudo apt update
		sudo apt install mono-complete 
	3) To run the game:
		mono DeepFlight.exe

MAC:
Not tested, but expected to be the same Linux: 

	1) Install mono:
		Visit: https://www.mono-project.com/docs/getting-started/install/mac/
	2) Run via terminal:
		mono DeepFlight.exe